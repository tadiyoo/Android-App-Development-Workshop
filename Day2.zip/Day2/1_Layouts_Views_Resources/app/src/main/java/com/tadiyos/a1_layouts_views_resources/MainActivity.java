package com.tadiyos.a1_layouts_views_resources;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView t1;
    Button b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        t1=findViewById(R.id.update);
        b1=findViewById(R.id.firstButton);

//        To handle event using java for Button 1
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                t1.setText("You Clicked Button 1");
            }
        });


    }

//    Using XML also we can handle an event for Button 2
    public void onSecondButton(View view) {
        t1.setText("You Clicked Button 2");
    }
}