package com.tadiyos.a11_recycler_view;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    RecyclerView r1;
    String s1[],s2[];
    int  imgRsc[]= {
            R.drawable.t1t,
            R.drawable.t2t,
            R.drawable.t3t,
            R.drawable.t4t,
            R.drawable.t13t,
            R.drawable.t12t,
            R.drawable.t7t,
            R.drawable.t8t,
            R.drawable.t2t,
            R.drawable.t10t,
            R.drawable.t11t,
            R.drawable.t12t,
            R.drawable.t13t,
            R.drawable.t14t,
            R.drawable.t15t,
            R.drawable.t3t,
    };

    MyOwnAdapter ad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        r1=findViewById(R.id.myRecycler);


        s1=getResources().getStringArray(R.array.family_name);
        s2=getResources().getStringArray(R.array.desc);


        ad=new MyOwnAdapter(this,s1,s2,imgRsc);



        r1.setAdapter(ad);
        r1.setLayoutManager(new LinearLayoutManager(this));
    }
}