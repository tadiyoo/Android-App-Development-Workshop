package com.tadiyos.a3_explicit_intents_and_activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Second_Activity extends AppCompatActivity {
    TextView tv1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_);

        tv1=findViewById(R.id.result);
        Bundle b1 = getIntent().getExtras();

        String s1= b1.getString("Tadiyos");
        tv1.setText(s1);
    }
}