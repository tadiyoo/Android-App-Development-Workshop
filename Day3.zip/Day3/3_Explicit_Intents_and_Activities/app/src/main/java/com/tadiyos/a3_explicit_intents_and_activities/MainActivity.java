package com.tadiyos.a3_explicit_intents_and_activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText ed1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed1= findViewById(R.id.data);
    }

    public void doSomething(View view) {
        Intent t1= new Intent(this,Second_Activity.class);
        t1.putExtra("Tadiyos",ed1.getText().toString());
        startActivity(t1);
    }

    public void doSomething2(View view) {
        switch (view.getId()){

            case R.id.b1:
                Intent intent1=new Intent(Intent.ACTION_VIEW, Uri.parse("http://wwww.google.com"));
                startActivity(intent1);
                break;

            case R.id.b2:
                Intent intent2=new Intent(Intent.ACTION_VIEW, Uri.parse("tel:13086690113"));
                startActivity(intent2);
                break;

            case R.id.b3:
                Intent intent3=new Intent(Intent.ACTION_VIEW, Uri.parse("geo:20.5937,78.9629"));  // the two data as longitude and latitude
                startActivity(intent3);
                break;
        }
    }
}